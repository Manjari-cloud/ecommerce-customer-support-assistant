"""Web UI module for the customer support assistant."""

