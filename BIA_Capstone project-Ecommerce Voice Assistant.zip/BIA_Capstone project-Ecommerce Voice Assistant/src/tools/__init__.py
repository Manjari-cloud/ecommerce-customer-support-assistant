"""Mock backend tools for order management, returns, and refunds."""

