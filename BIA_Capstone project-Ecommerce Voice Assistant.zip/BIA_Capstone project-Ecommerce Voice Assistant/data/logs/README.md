# Conversation Logs

This directory stores conversation logs for evaluation and analysis.

## Log Format

Conversation logs are stored as JSON files with the following structure:

```json
{
  "conversation_id": "uuid",
  "timestamp": "2024-01-20T10:30:00",
  "messages": [
    {
      "role": "user",
      "content": "Where is my order?",
      "timestamp": "2024-01-20T10:30:00"
    },
    {
      "role": "assistant",
      "content": "I can help you track your order...",
      "tool_calls": [...],
      "rag_used": true,
      "timestamp": "2024-01-20T10:30:01"
    }
  ]
}
```

## Usage

Logs can be used for:
- Performance analysis
- Response quality evaluation
- User behavior insights
- System improvement

## Sample Files

Sample conversation logs will be generated during evaluation runs.

